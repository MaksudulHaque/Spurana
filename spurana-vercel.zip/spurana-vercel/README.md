# Spurana ✦ — Vercel Build

Converted from Netlify → **Vercel** (free tier, no paid plan needed).

## File structure

```
spurana-vercel/
├── index.html             ← Fully self-contained app
├── manifest.json          ← PWA install metadata
├── service-worker.js      ← Offline caching
├── vercel.json            ← Vercel deploy config
├── firebase-rules.json    ← Realtime Database security rules
├── api/
│   └── ai.js              ← Serverless AI proxy (replaces Netlify function)
└── README.md              ← This file
```

## What changed from Netlify

| Before (Netlify)                     | After (Vercel)              |
|--------------------------------------|-----------------------------|
| `netlify.toml`                       | `vercel.json`               |
| `netlify/functions/ai.js`            | `api/ai.js`                 |
| `/.netlify/functions/ai` (fetch URL) | `/api/ai` (fetch URL)       |
| Netlify env vars                     | Vercel env vars (same name) |

---

## Deploy to Vercel (Free)

### Option A — Via GitHub (recommended)

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo
4. Leave **Framework Preset** as `Other`
5. Leave **Build Command** and **Output Directory** blank
6. Click **Deploy**

After deploy, add your env var:
- Go to your project → **Settings → Environment Variables**
- Add: `ANTHROPIC_API_KEY` = your Anthropic API key
- Click **Save** → then **Redeploy** (top-right of Deployments tab)

### Option B — Via Vercel CLI

```bash
npm i -g vercel
cd spurana-vercel
vercel
```

Follow the prompts. Then set the env var:
```bash
vercel env add ANTHROPIC_API_KEY
# Paste your key when prompted
vercel --prod
```

---

## Firebase — authorize your new domain

After deploy, go to:
**Firebase Console → Authentication → Settings → Authorized domains**

Add your Vercel domain (e.g. `spurana.vercel.app`) so sign-in works in production.

Also paste `firebase-rules.json` contents into:
**Firebase Console → Realtime Database → Rules**

---

## Run locally (no change)

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`

- **Email**: anything (e.g. `you@soul.com`)
- **Sacred Key**: 6+ characters
- **Invite Code**: `SPURANA-2024`

---

— ✦ —

**Maksudul · Keeper of this Realm**

NWP · Sacred Architecture · v6.1 · 2026 · Vercel Edition
