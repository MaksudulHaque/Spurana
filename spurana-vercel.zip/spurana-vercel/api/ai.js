// Spurana ✦ Anthropic API proxy — Vercel Serverless Function
// Accepts either a server-side ANTHROPIC_API_KEY env var OR a clientKey in the body.
// Client-supplied keys win when present (so a user can pay for their own usage).

export default async function handler(req, res) {
  // CORS headers (allow same-origin and any origin for API usage)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { systemPrompt, userText, maxTokens, clientKey } = req.body || {};
    const apiKey = (clientKey && clientKey.trim()) || process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: 'API key not configured' });
    }

    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: maxTokens || 200,
        system: systemPrompt || '',
        messages: [{ role: 'user', content: userText || '' }]
      })
    });

    const data = await resp.json();
    const text = (data && data.content && data.content[0] && data.content[0].text) || '';

    return res.status(200).json({ text });
  } catch (e) {
    return res.status(500).json({ error: e.message || 'Unknown error' });
  }
}
